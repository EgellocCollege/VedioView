package com.demo.videoview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.PixelCopy;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.recyclerview.widget.RecyclerView;


import java.util.List;


public class VideoViewAdapter extends RecyclerView.Adapter<VideoViewAdapter.ViewHolder> implements LifecycleObserver {


    static String TAG = VideoViewAdapter.class.getSimpleName();

    private LayoutInflater mInflater;
    private List<Uri> mCoursesList;
    private MainActivity mContext;

    public VideoViewAdapter(List<Uri> mCoursesList, MainActivity context) {
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
        this.mCoursesList = mCoursesList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.item_video_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        mContext.getLifecycle().addObserver(holder);
        holder.videoview.setVideoURI(mCoursesList.get(position));

        holder.videoview.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                Log.e(TAG, "videoview onCompletion");
            }
        });
        holder.videoview.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
                Log.e(TAG, "videoview onError");
                return false;
            }
        });
        holder.videoview.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setLooping(true);
            }
        });
        holder.videoview.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mediaPlayer, int what, int extra) {
                Log.e(TAG, "videoview onInfo MediaPlayer.what=" + what);
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START){
                    holder.videoview.setBackgroundColor(Color.TRANSPARENT);
                }
                Log.e(TAG, "videoview onInfo");
                return false;
            }
        });
        holder.videoview.start();
    }

    @Override
    public int getItemCount() {
        return mCoursesList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder implements LifecycleObserver{
        VideoView videoview;
        ViewHolder(@NonNull View view) {
            super(view);
            videoview = view.findViewById(R.id.video_view);
            videoview.getHolder().addCallback(new VideoViewCallBack(videoview));
        }

        //监听Activity onPause事件
        @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE) //LifecycleObserver特有的写法
        public void onPause() {
            Log.e(TAG, " onPause");
            if (!videoview.isPlaying()) {
                return;
            }
            Bitmap surfaceBitmap = Bitmap.createBitmap(videoview.getWidth(), videoview.getHeight(), Bitmap.Config.ARGB_8888);
            PixelCopy.OnPixelCopyFinishedListener listener = copyResult -> {
                // success/failure callback
            };

            PixelCopy.request(videoview, surfaceBitmap, listener, new Handler(Looper.getMainLooper()));
            // visualize the retrieved bitmap on your imageview
            videoview.setBackground(new BitmapDrawable(surfaceBitmap));
        }
    }

    static class VideoViewCallBack implements SurfaceHolder.Callback {
        VideoView mVideoview;

        public VideoViewCallBack(VideoView videoview) {
            this.mVideoview = videoview;
        }

        @Override
        public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
            Log.e(TAG, "videoview surfaceCreated, VideoView= " + mVideoview);
            this.mVideoview.start();
        }

        @Override
        public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

            Log.e(TAG, "videoview surfaceChanged, VideoView= " + mVideoview);
        }

        @Override
        public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
            Log.e(TAG, "videoview surfaceDestroyed, VideoView= " + mVideoview);

//            mVideoview.setBackgroundColor(Color.GREEN);
        }
    }


}
