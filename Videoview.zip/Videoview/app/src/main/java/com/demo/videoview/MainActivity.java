package com.demo.videoview;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.PixelCopy;
import android.view.SurfaceHolder;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    static String TAG = MainActivity.class.getSimpleName();

    ViewPager2 viewPager;
    VideoView videoview;
    Button btn;
    ImageView img;

    VideoViewAdapter mVideoViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(TAG, " onCreate");
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.view_pager);
        videoview = findViewById(R.id.video_view);
        btn =  findViewById(R.id.btn);
        img =  findViewById(R.id.image);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SecondActivity.class));
            }
        });

//        setupMatchCoursesViewpager();
        setupVideoViewpager();

        startplay();

    }

    private void setupMatchCoursesViewpager() {
        int currentItem = 1;
        List<MatchCourse> mMatchCourses = this.getCourseData();
        CourseTopicsViewPager courseTopicsViewPager = new CourseTopicsViewPager(mMatchCourses, this);
        viewPager.setAdapter(courseTopicsViewPager);
        viewPager.setCurrentItem(currentItem);
        viewPager.setOffscreenPageLimit(mMatchCourses.size() - 1);
    }

    private void setupVideoViewpager() {
        int currentItem = 1;
        List<Uri> mMatchCourses = this.getVideoeData();
        mVideoViewAdapter = new VideoViewAdapter(mMatchCourses, this);

        viewPager.setAdapter(mVideoViewAdapter);
        viewPager.setCurrentItem(currentItem);
        viewPager.setOffscreenPageLimit(1);
    }

    private void startplay() {
        videoview.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.aerial));
        videoview.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                Log.e(TAG, "videoview onCompletion");
            }
        });
        videoview.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
                Log.e(TAG, "videoview onError");
                return false;
            }
        });
        videoview.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                Log.e(TAG, "videoview onPrepared");
            }
        });
        videoview.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mediaPlayer, int i, int i1) {
                Log.e(TAG, "videoview onResume");
                return false;
            }
        });
        videoview.getHolder().addCallback(new SurfaceHolder.Callback() {

            @Override
            public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
                videoview.start();
            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {

            }
        });

        videoview.start();

    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.e(TAG, " onResume");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e(TAG, " onStart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e(TAG, " onStop");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.e(TAG, " onPause");

        Bitmap surfaceBitmap = Bitmap.createBitmap(videoview.getWidth(), videoview.getHeight(), Bitmap.Config.ARGB_8888);
        PixelCopy.OnPixelCopyFinishedListener listener = copyResult -> {
            // success/failure callback
        };

        PixelCopy.request(videoview, surfaceBitmap, listener, new Handler(Looper.getMainLooper()));
        // visualize the retrieved bitmap on your imageview

        img.setImageBitmap(surfaceBitmap);


    }




    public List<MatchCourse> getCourseData() {
        return Arrays.asList(
                new MatchCourse(1, "Digital Marketing", "12 courses available", R.drawable.education_2),
                new MatchCourse(2, "Business", "50 courses available", R.drawable.education_3),
                new MatchCourse(3, "Development", "265 courses available", R.drawable.education_4),
                new MatchCourse(4, "Security", "18 courses available", R.drawable.education_1),
                new MatchCourse(5, "Ethical Hacking", "36 courses available", R.drawable.education_5),
                new MatchCourse(6, "Mobile", "145 courses available", R.drawable.education_6)

        );
    }

    public List<Uri> getVideoeData() {
        return Arrays.asList(
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.aerial),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.bubbles),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.cat),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.flowers),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.mountain),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.rain),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.sand),
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.winter)
        );
    }
}