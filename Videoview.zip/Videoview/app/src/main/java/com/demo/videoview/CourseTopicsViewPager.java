package com.demo.videoview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;

import java.util.List;


public class CourseTopicsViewPager extends RecyclerView.Adapter<CourseTopicsViewPager.ViewHolder> {
    private LayoutInflater mInflater;
    private List<MatchCourse> mCoursesList;
    private Context mContext;

    public CourseTopicsViewPager(List<MatchCourse> mCoursesList, Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
        this.mCoursesList = mCoursesList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.item_shop_card, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Glide.with(mContext)
                .load(mCoursesList.get(position).getImageResource())
//                .transform(new CenterCrop(), new RoundedCorners(24))
//                .transform(new RoundedCorners(40))
                .transform(new CenterCrop())
                .into(holder.image);
    }

    @Override
    public int getItemCount() {
        return mCoursesList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        ViewHolder(@NonNull View view) {
            super(view);
            image = view.findViewById(R.id.image);
        }


    }
}
